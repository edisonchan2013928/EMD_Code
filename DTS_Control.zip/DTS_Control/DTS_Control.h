#ifndef DTS_CONTROL_H
#define DTS_CONTROL_H

#include "Skew_Bound.h"
#include "Proj_LB.h"
#include "IM_LB.h"
#include "UB_H.h"
#include "GEMD_UB.h"
#include "CompStage.h"

void DTS_Control(Pair*Pair_Array,double**dataSetVector,double**costMatrix,double**groundMatrix,int*hilbert_DimVector,int dim,double epsilon,EMD& model,int exact_Sel)
{
	double ratio=(1+epsilon)/(1-epsilon);

	//variable declarations
	vector<double> UB_delta_qVector;
	vector<double> UB_delta_pVector;
	vector< vector<double> > SkewMater_qVector;
	vector< vector<double> > SkewMater_pVector;
	double*q_dash; 
	double*p_dash;
	int NZ_q;
	int NZ_p;
	double dist;

	vector<double> q_bar;
	vector<double> p_bar;

	//Used in Proj_LB
	vector< cdf_Entry > q_vec_CDF;
	vector< cdf_Entry > p_vec_CDF;
	vector< vector<gIndexRecord> > gIndexTableVector;

	//Used in IM_LB
	vector< vector<component> > SortCostVector;

	//Used in UB_G
	vector<index_Cost> sortCostList;

	double LB;
	double UB;
	double threshold;

	int skew_qIndex, prev_skew_qIndex;
	int skew_pIndex, prev_skew_pIndex;
	double skew_UB;

	//Initialization
	initMaterialVector(UB_delta_qVector,SkewMater_qVector,dim);
	initMaterialVector(UB_delta_pVector,SkewMater_pVector,dim);
	init_SkewedVector(q_dash,p_dash,dim);

	gIndexTableVector_Creation(groundMatrix,dim,gIndexTableVector);
	initCDF(q_vec_CDF,gIndexTableVector);
	initCDF(p_vec_CDF,gIndexTableVector);

	init_component(SortCostVector,costMatrix,dim);

	initGEMD(dim);
	list_PreProcess(costMatrix,sortCostList,dim);

	clock_t start_s;
	clock_t stop_s;

	//int noPrune=0;
	
	int iteration=0; //statistics
	double validate_error=0; //statistics
	double prev_skew_UB; //statistics
	start_s=clock();
	for(int p=0;p<pairNum;p++)
	{
		//Cascade Step 1
		LB=Proj_LB(dataSetVector[Pair_Array[p].L_Index],dataSetVector[Pair_Array[p].R_Index],q_vec_CDF,p_vec_CDF,gIndexTableVector,dim);
		//UB=hilbertUB(dataSetVector[Pair_Array[p].L_Index],dataSetVector[Pair_Array[p].R_Index],costMatrix,hilbert_DimVector,dim);

		/*if(UB<=ratio*LB)
		{
			result_pairVector.push_back((2*LB*UB)/(LB+UB));
			continue;
		}*/

		//Cascade Step 2
		/*UB=greedyAlgorithm(sortCostList,costMatrix,dim,dataSetVector[Pair_Array[p].L_Index],dataSetVector[Pair_Array[p].R_Index]);
		UB=min(UB,greedyAlgorithm(sortCostList,costMatrix,dim,dataSetVector[Pair_Array[p].L_Index],dataSetVector[Pair_Array[p].R_Index]));

		if(UB<=ratio*LB)
		{
			result_pairVector.push_back((2*LB*UB)/(LB+UB));
			continue;
		}*/

		//Cascade Step 3
		//LB=max(LB,IM_LB(dataSetVector[Pair_Array[p].L_Index],dataSetVector[Pair_Array[p].R_Index],SortCostVector,dim));

		/*if(UB<=ratio*LB)
		{
			result_pairVector.push_back((2*LB*UB)/(LB+UB));
			continue;
		}*/

		//noPrune++;

		threshold=epsilon*LB;

		NZ_q=SVSF_Mater(dataSetVector[Pair_Array[p].L_Index],costMatrix,dim,q_dash,UB_delta_qVector,SkewMater_qVector);
		NZ_p=SVSF_Mater(dataSetVector[Pair_Array[p].R_Index],costMatrix,dim,p_dash,UB_delta_pVector,SkewMater_pVector);

		//DTS Incremental Method
		skew_qIndex=1;
		skew_pIndex=1;
		prev_skew_qIndex=0;
		prev_skew_pIndex=0;

		while(true)
		{
			iteration++; //Statistics
			skew_UB=UB_delta_qVector[skew_qIndex]+UB_delta_pVector[skew_pIndex];
			if(skew_UB<=threshold)
			{
				prev_skew_qIndex=skew_qIndex;
				prev_skew_pIndex=skew_pIndex;

				//Nothing to skew
				if(skew_qIndex==NZ_q-1 && skew_pIndex==NZ_p-1)
					break;

				//Ensure no overflow
				if(skew_qIndex+1<NZ_q)
					skew_qIndex++;
				if(skew_pIndex+1<NZ_p)
					skew_pIndex++;

				prev_skew_UB=skew_UB;
				skew_UB=UB_delta_qVector[skew_qIndex]+UB_delta_pVector[skew_pIndex];
			}
			else
				break;
		}

		validate_error+=prev_skew_UB/LB;

		for(int d=0;d<dim;d++)
		{
			q_dash[d]=SkewMater_qVector[prev_skew_qIndex][d];
			p_dash[d]=SkewMater_pVector[prev_skew_pIndex][d];
		}
		
		if(exact_Sel==1) //SIA
		{
			dist=model.getDist(q_dash,p_dash,inf);
			result_pairVector.push_back(dist);
		}
		if(exact_Sel==2) //TRA
		{
			IgnoreZero(q_dash,p_dash,q_bar,p_bar,costMatrix,dim);
			result_pairVector.push_back(emdComputation(q_bar,p_bar)/**scal_Factor*/);
		}

	}
	stop_s=clock();

	//cout<<((double)(stop_s-start_s)/CLOCKS_PER_SEC)/*/(double)pairNum*/<<endl;
	cout<< "DTS Control:"<<(double)pairNum/((double)(stop_s-start_s)/CLOCKS_PER_SEC)<<endl;
	cout<<"Average Iteration: "<<(double)iteration/pairNum<<endl;
	cout<<"Validation Error (Avg): "<<(double)validate_error/pairNum<<endl;
	//cout<<"pruning ratio; "<<(double)(pairNum-noPrune)/pairNum<<endl;
	//cout<<(double)(pairNum-noPrune)/pairNum<<endl;
	//cout<<(double)(stop_s-start_s)/CLOCKS_PER_SEC<<endl;
}

#endif
