#include <cmath>
#include <utility>
#include "myemd.h"

//#ifndef __DEBUG__
//#define __DEBUG__
//#endif


/* DEFINITIONS */
#define MAX_SIG_SIZE   1100
#define MAX_ITERATIONS 5000
#define INFINITY       1e20
#define EPSILON        1e-6

#define MAX_SIG_SIZE1  (MAX_SIG_SIZE+1)  /* FOR THE POSIBLE DUMMY FEATURE */



//Modified by Edison (Comment line23-line32)

/* GLOBAL VARIABLE DECLARATION */
//static int _n1, _n2;                          /* SIGNATURES SIZES */
//static double _C[MAX_SIG_SIZE1][MAX_SIG_SIZE1];/* THE COST MATRIX */
//double** _C; // for later use
//static node2_t _X[MAX_SIG_SIZE1*2];            /* THE BASIC VARIABLES VECTOR */
/* VARIABLES TO HANDLE _X EFFICIENTLY */
/*static node2_t *_EndX, *_EnterX;
static char _IsX[MAX_SIG_SIZE1][MAX_SIG_SIZE1];
static node2_t *_RowsX[MAX_SIG_SIZE1], *_ColsX[MAX_SIG_SIZE1];
static double _maxW;
static double _maxC;*/

#if DEBUG_LEVEL > 0
static void printSolution();
#endif


EMD::EMD()
{

}

EMD::~EMD()
{
	delete []bin_coord;
}

void EMD::set(int bin_num, int feat_dim, double* bin_coord)
{
	this->bin_num = bin_num;
	this->feat_dim = feat_dim;
	int cnt = bin_num * feat_dim;
	this->bin_coord = new double[cnt];

	for (int i = 0; i < cnt; i++)
		this->bin_coord[i] = bin_coord[i];

	// build cost matrix
	cost_matrix = new double *[bin_num + 1];
	cost_matrix_INT = new int *[bin_num + 1];
	maxc = 0;
	for (int i = 0; i < bin_num; i++)
	{
		cost_matrix[i] = new double[bin_num + 1];
		cost_matrix_INT[i] = new int[bin_num + 1];
		for (int j = 0; j < bin_num; j++) 
		{
			double tmp = 0;
			for (int k = 0; k < feat_dim; k++)
			{
				tmp += pow(bin_coord[i*feat_dim+k] - bin_coord[j*feat_dim+k], 2);
			}
			cost_matrix[i][j] = sqrt(tmp);
			if (cost_matrix[i][j] > maxc) maxc = cost_matrix[i][j];
			cost_matrix_INT[i][j] = (int)(cost_matrix[i][j] * TIMESFACTOR);
		}
	}

	// build sorted index
	sorted_index = new int *[bin_num];
	vector< pair<double, int> > arr(bin_num);
	for (int i = 0; i < bin_num; i++)
	{
		sorted_index[i] = new int[bin_num];
		for (int j = 0; j < bin_num; j++)
		{
			arr[j].first = cost_matrix[i][j];
			arr[j].second = j;
		}
		sort(arr.begin(), arr.end());
		for (int j = 0; j < bin_num; j++)
		{
			sorted_index[i][j] = arr[j].second;
		}
	}
}

void EMD::set_DimRed(int bin_num, int feat_dim, double ** costs_red)
{
	this->bin_num = bin_num;
	this->feat_dim = feat_dim;
	this->cost_matrix = costs_red;

	int cnt = bin_num * feat_dim;

	// build cost matrix
	//cost_matrix = new double *[bin_num];
	//cost_matrix = costs_red;
	cost_matrix_INT = new int *[bin_num];
	maxc = 0;
	for (int i = 0; i < bin_num; i++)
	{
		//cost_matrix[i] = new double[bin_num];
		cost_matrix_INT[i] = new int[bin_num];
		for (int j = 0; j < bin_num; j++) 
		{
			// double tmp = 0;
			// for (int k = 0; k < feat_dim; k++)
			// {
			// 	tmp += pow(bin_coord[i*feat_dim+k] - bin_coord[j*feat_dim+k], 2);
			// }
			// cost_matrix[i][j] = sqrt(tmp);
			if (cost_matrix[i][j] > maxc) maxc = cost_matrix[i][j];
			cost_matrix_INT[i][j] = (int)(cost_matrix[i][j] * TIMESFACTOR);
		}
	}

	// build sorted index
	sorted_index = new int *[bin_num];
	vector< pair<double, int> > arr(bin_num);
	for (int i = 0; i < bin_num; i++)
	{
		sorted_index[i] = new int[bin_num];
		for (int j = 0; j < bin_num; j++)
		{
			arr[j].first = cost_matrix[i][j];
			arr[j].second = j;
		}
		sort(arr.begin(), arr.end());
		for (int j = 0; j < bin_num; j++)
		{
			sorted_index[i][j] = arr[j].second;
		}
	}

}

void EMD::set_bufsize(int sz)
{
	tests.resize(sz);
	pids.resize(sz);
}


void EMD::initCCA()
{
	test.readCostMatrix(cost_matrix_INT, sorted_index); // should proceed after EMD::set(...)
}

//Changed back by Edison
//*******************************************************//
void EMD::initLemon(int W)
{
	lemon.init(bin_num, W, cost_matrix_INT);
}
//*******************************************************//

void EMD::pca()
{
	// prepare the input
	bins.setcontent(bin_num, feat_dim, bin_coord);

	pcabuildbasis(bins, bin_num, feat_dim, info, eig_values, eig_vectors);
	
	// project the bins to get the scores
	bin_scores.setlength(bin_num, feat_dim);
	rmatrixgemm(bin_num, feat_dim, feat_dim, 1.0, bins, 0, 0, 0, eig_vectors, 0, 0, 0, 0.0, bin_scores, 0, 0);
}

void EMD::get_eigvec(const int kth, double* out_array)
{
	for (int i = 0; i < feat_dim; i++)
		out_array[i] = eig_vectors[i][kth-1];
}


void EMD::get_scores(const int kth, double* out_array)
{
	for (int i = 0; i < bin_num; i++)
		out_array[i] = bin_scores[i][kth-1];
}

//Comment by Edison
/*double EMD::dist(double* w1, double* w2)
{
	double t1 = clock();
	signature_t s1 = {bin_num, bin_coord, w1};
	signature_t s2 = {bin_num, bin_coord, w2};
	double res = emd(&s1, &s2, 0, 0);

#ifdef __DEBUG__
	cout << "#" << (clock() - t1) / CLOCKS_PER_SEC << endl;
#endif

	return res;
}*/

double EMD::getDist(double* w1, double* w2, double cur_bound)
{
	int* wa = new int[bin_num];
	int* wb = new int[bin_num];
	for (int i = 0; i < bin_num; i++)
	{
		wa[i] = (int)w1[i];
		wb[i] = (int)w2[i];
	}
	
	//double t1 = clock();

	test.initSIA(SIA, bin_num, bin_num, wa, wb);

	int tmp = test.runSIA(0, cur_bound);

/*#ifdef __DEBUG__	
	cout << "\n~" << (clock() - t1) / CLOCKS_PER_SEC << endl;
#endif*/

	/*if (tmp == -1) {		
		return -1;
	}*/
	
	double res = IntToFloat(tmp);

	// normalize or not

	delete[] wa;
	delete[] wb;

	return res;
}

//Comment by Edison
//Changed back by Edison
//*******************************************************//
double EMD::getCapScalingDist(double* w1, double* w2)
{
	double res = lemon.getAssignment(w1, w2, 2);
	return res / TIMESFACTOR;
}

double EMD::getCostScalingDist(double* w1, double* w2)
{
	double res = lemon.getAssignment(w1, w2, 1);
	return res / TIMESFACTOR;
}

double EMD::getNetworkSimplexDist(double* w1, double* w2)
{
	double res = lemon.getAssignment(w1, w2, 3);
	return res / TIMESFACTOR;
}
//*******************************************************//

void EMD::prepareEMD(int ith, double* w1, double* w2)
{
	int* wa = new int[bin_num];
	int* wb = new int[bin_num];
	for (int i = 0; i < bin_num; i++)
	{
		wa[i] = (int)w1[i];
		wb[i] = (int)w2[i];
	}

	tests[ith].initSIA(SIA, bin_num, bin_num, wa, wb);
	delete[] wa;
	delete[] wb;
}

double EMD::getIthDist(int ith, double cur_bound)
{

	
	double t1 = clock();



	int tmp = tests[ith].runSIA(0, cur_bound);

#ifdef __DEBUG__	
	cout << "\n~" << (clock() - t1) / CLOCKS_PER_SEC << endl;
#endif

	if (tmp == -1) {		
		return -1;
	}
	
	double res = IntToFloat(tmp);

	// normalize or not
	//double res = IntToFloat(test.getAssignCost()) / (double)test.getTotalFlows(); // Yu hardcode
	//double res = IntToFloat(test.getAssignCost());
	//double res = test.getAssignCost() / (double)test.getTotalFlows();



	//test.printstat("o");
	return res;
}


	
double EMD::getBoundIM(const double * point1, const double * point2)
{
	double * p1 = new double[bin_num];
	double * p2 = new double[bin_num];
	memcpy(p1, point1, bin_num * sizeof(double));
	memcpy(p2, point2, bin_num * sizeof(double));
	//for (int i = 0; i < bin_num; i++)
	//{
	//	printf("%lf ", p1[i]);
	//}
	//printf("\n");
	//system("pause");
	//for (int i = 0; i < bin_num; i++)
	//{
	//	printf("%lf ", p2[i]);
	//}
	//printf("\n");
	//system("pause");
	bool m_normOptimized = true;
	double  w  = 0;

	if (m_normOptimized) {
		double  w2  = 0;
		double diff;
		for (int i = 0; i < bin_num; i++) {
			diff  = (p1[i] < p2[i]) ? p1[i] : p2[i];
			w    += p1[i];
			w2   += p2[i];
			p1[i]-= diff;
			p2[i]-= diff;
			
		}
		w = (w < w2) ? w : w2;
	} else {
		double  w2  = 0;
		for (int i = 0; i < bin_num; i++) {
			w    += p1[i];			
		}
		for (int e = 0; e < bin_num; e++) {
			w2   += p2[e];			
		}
		w = (w < w2) ? w : w2;
	}

	double rowdist = 0, coldist = 0;

	//compute rowdist
	for (int i = 0; i < bin_num; i++) {
		double mass = p1[i];
		int e = 0;
		while(mass >= 1e-6) {
			double movableMass = (mass < p2[sorted_index[i][e]]) ? mass : p2[sorted_index[i][e]];
			rowdist += cost_matrix[i][sorted_index[i][e]] * movableMass;
			mass	-= movableMass;
			e++; 
		}					
	}
	//compute coldist
	for (int e = 0; e < bin_num; e++) {
		double mass = p2[e];
		int i = 0;
		while(mass >= 1e-6) {
			double movableMass = (mass < p1[sorted_index[e][i]]) ? mass : p1[sorted_index[e][i]];
			coldist += cost_matrix[sorted_index[e][i]][e] * movableMass;
			mass	-= movableMass;
			i++; 
		}					
	}

	if (m_normOptimized) {
		delete [] p1;
		delete [] p2;
	}

	//return ((rowdist > coldist) ? rowdist : coldist) / w;
	return (rowdist > coldist) ? rowdist : coldist;
}


