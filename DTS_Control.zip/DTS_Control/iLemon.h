/*
 * Lemon.h
 *
 *  Created on: Apr 8, 2013
 *      Author: yu
 */

#ifndef LEMON_H_
#define LEMON_H_


#include "lemon/list_graph.h"
#include "lemon/smart_graph.h"
#include "lemon/lgf_reader.h"
#include "lemon/network_simplex.h"
#include "lemon/capacity_scaling.h"
#include "lemon/cost_scaling.h"
#include "lemon/cycle_canceling.h"
#include "lemon/concepts/digraph.h"
#include "lemon/concepts/heap.h"
#include "lemon/concept_check.h"


//typedef lemon::ListDigraph Digraph;
//DIGRAPH_TYPEDEFS(lemon::ListDigraph);

class iLemon {
public:
	iLemon();
	virtual ~iLemon();

	//void init(int bin_num, int W, double **costMat);
	void init(int bin_num, int W, int **costMat);
	double getAssignment(double *w1, double *w2, int MODE);
private:

	//lemon::Node v, w;
	lemon::SmartDigraph graph;
	lemon::SmartDigraph::ArcMap<int> cost;
	lemon::SmartDigraph::ArcMap<int> capacity;
	lemon::SmartDigraph::NodeMap<int> supply;
	lemon::ConstMap<lemon::SmartDigraph::Arc, int> lower;
	int TotalCap;
	int noA, noB;
	int **costs;
};

#endif /* LEMON_H_ */
