#ifndef PROJ_LB_H
#define PROJ_LB_H

#include "fixed_Cost_Matrix.h"

typedef vector<double> cdf_Entry;

struct gIndexRecord
{
	double gIndexValue;
	vector<int> dim_Set;
};

bool recordCompare(gIndexRecord record1,gIndexRecord record2)
{
	return record1.gIndexValue<record2.gIndexValue;
}

int ground_Dim;

void loadGroundFile(fstream& groundFile,char*groundFileName,double**& groundMatrix,double* &feat,int dim)
{

	double groundValue;
	groundFile.open(groundFileName);
	if(groundFile.is_open()==false)
	{
		cout<<"Cannot Open ground file!"<<endl;
		return;
	}

	groundFile>>ground_Dim;

	//Used in SIA
	//*******************************************************//
	feat = new double[dim * ground_Dim];
	//*******************************************************//

	//Used in LB_Proj
	//*******************************************************//
	groundMatrix=new double*[dim];

	for(int d=0;d<dim;d++)
		groundMatrix[d]=new double[ground_Dim];
	//*******************************************************//

	for(int d=0;d<dim;d++)
	{
		for(int g=0;g<ground_Dim;g++)
		{
			groundFile>>groundValue;
			groundMatrix[d][g]=groundValue;
			feat[d*ground_Dim+g]=groundValue;
		}
	}
		

}

//Specifically used by SIA
/*void loadGroundFile_SIA(char*groundFileName,fstream& groundFile,double* & feat,int dim,int& ground_Dim)
{
	int cnt;
	groundFile.open(groundFileName);
	if(groundFile.is_open()==false)
	{
		cout<<"Cannot Open ground file!"<<endl;
		return;
	}
	groundFile>>ground_Dim;
	
	cnt = dim * ground_Dim;
	
	feat = new double[cnt];
	for (int i = 0; i < cnt; i++)
		groundFile>>feat[i];
}*/

void gIndexTableVector_Creation(double**groundMatrix,/*int ground_Dim,*/int dim, vector< vector<gIndexRecord> >& gIndexTableVector)
{
	//initalization of gIndexTable
	vector<gIndexRecord> tempVector;
	for(int gIndex=0;gIndex<ground_Dim;gIndex++)
	{
		gIndexTableVector.push_back(tempVector);
	}

	bool abnormal;
	int beingGG;
	gIndexRecord tempRecord;

	for(int gIndex=0;gIndex<ground_Dim;gIndex++)
	{
		for(int d=0;d<dim;d++)
		{
			abnormal=false;

			for(int gg=0;gg<(int)gIndexTableVector[gIndex].size();gg++)
			{
				if(fabs(groundMatrix[d][gIndex]-gIndexTableVector[gIndex][gg].gIndexValue)<0.0001)//they are equal with each other
				{
					abnormal=true;
					beingGG=gg;
					break;
				}
			}

			if(abnormal==false)
			{
				tempRecord.gIndexValue=groundMatrix[d][gIndex];
				tempRecord.dim_Set.push_back(d);
				gIndexTableVector[gIndex].push_back(tempRecord);
				//clear
				tempRecord.dim_Set.clear();
			}
			else
			{
				gIndexTableVector[gIndex][beingGG].dim_Set.push_back(d);
			}

		}

		//Sort the record according to the increasing order of gIndexValue
		sort(gIndexTableVector[gIndex].begin(),gIndexTableVector[gIndex].end(),recordCompare);
	}
}

//Can be done in one time online processing
//*********************************************************************************************************//
void initCDF(vector< cdf_Entry >& vec_CDF,vector< vector<gIndexRecord> >& gIndexTableVector/*,int ground_Dim*/)
{
	cdf_Entry temp_Entry;

	for(int gIndex=0;gIndex<ground_Dim;gIndex++)
		vec_CDF.push_back(temp_Entry);

	for(int gIndex=0;gIndex<ground_Dim;gIndex++)
		for(int gg=0;gg<(int)gIndexTableVector[gIndex].size();gg++)
			vec_CDF[gIndex].push_back(0);
}
//*********************************************************************************************************//

void createCDF(double*vec,vector< vector<gIndexRecord> >& gIndexTableVector,vector< cdf_Entry >& vec_CDF/*,int ground_Dim*/,int dim)
{
	//cdf_Entry temp_Entry;
	int dimIndex;

	/*for(int gIndex=0;gIndex<ground_Dim;gIndex++)
		vec_CDF.push_back(temp_Entry);

	for(int gIndex=0;gIndex<ground_Dim;gIndex++)
		for(int gg=0;gg<(int)gIndexTableVector[gIndex].size();gg++)
			vec_CDF[gIndex].push_back(0);*/

	//Initialization of vec_CDF
	for(int gIndex=0;gIndex<ground_Dim;gIndex++)
		for(int gg=0;gg<(int)gIndexTableVector[gIndex].size();gg++)
			vec_CDF[gIndex][gg]=0;

	//first build-up the pdf function
	//***********************************//
	for(int gIndex=0;gIndex<ground_Dim;gIndex++)
	{
		for(int gg=0;gg<(int)gIndexTableVector[gIndex].size();gg++)
		{
			for(int d=0;d<(int)gIndexTableVector[gIndex][gg].dim_Set.size();d++)
			{
				dimIndex=gIndexTableVector[gIndex][gg].dim_Set[d];
				vec_CDF[gIndex][gg]+=vec[dimIndex];
			}
		}
	}
	//***********************************//

	//Make it to be the cdf
	//***********************************//
	for(int gIndex=0;gIndex<ground_Dim;gIndex++)
		for(int gg=1;gg<(int)gIndexTableVector[gIndex].size();gg++)
			vec_CDF[gIndex][gg]=vec_CDF[gIndex][gg-1]+vec_CDF[gIndex][gg];
	//***********************************//
}

double Proj_LB(double*q,double*p,vector< cdf_Entry >& q_vec_CDF,vector< cdf_Entry >& p_vec_CDF,vector< vector<gIndexRecord> >& gIndexTableVector/*,int ground_Dim*/,int dim)
{
	double scale_Value=sqrt((double)ground_Dim)/ground_Dim;
	double LB_Value;
	double EMD_1DValue;

	double LValue;
	double RValue;
	double gDifference;

	LB_Value=0;

	//Obtain the cdf of q_vec_CDF and p_vec_CDF
	//***********************************************//
	createCDF(q,gIndexTableVector,q_vec_CDF,dim);
	createCDF(p,gIndexTableVector,p_vec_CDF,dim);
	//***********************************************//

	for(int gIndex=0;gIndex<ground_Dim;gIndex++)
	{
		EMD_1DValue=0;
		for(int gg=0;gg<(int)gIndexTableVector[gIndex].size()-1;gg++)
		{
			LValue=q_vec_CDF[gIndex][gg];
			RValue=p_vec_CDF[gIndex][gg];
			//LValue=dataSet_CDF[Pair_Array[p].L_Index][gIndex][gg];
			//RValue=dataSet_CDF[Pair_Array[p].R_Index][gIndex][gg];
			gDifference=gIndexTableVector[gIndex][gg+1].gIndexValue-gIndexTableVector[gIndex][gg].gIndexValue;
			EMD_1DValue+=fabs(RValue-LValue)*gDifference;
		}
		LB_Value+=EMD_1DValue;
	}
	LB_Value*=scale_Value;

	return LB_Value;
	//result_pairVector.push_back(LB_Value);
}

#endif
