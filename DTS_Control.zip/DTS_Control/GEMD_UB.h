#ifndef GEMD_UB_H
#define GEMD_UB_H

#include "fixed_Cost_Matrix.h"

//These two variables are used in greedyAlgorithm
double*queryTempVector;
double*dataTempVector;

struct index_Cost
{
	int qIndex;
	int pIndex;
	double costValue;
};

bool compare(index_Cost lhs, index_Cost rhs)
{
	return lhs.costValue<rhs.costValue;
}

void initGEMD(int dim)
{
	queryTempVector=new double[dim];
	dataTempVector=new double[dim];
}

void list_PreProcess(double**costMatrix,vector<index_Cost>& sortCostList,int dim)
{
	//clear for safety
	sortCostList.clear();

	index_Cost temp;
	for(int i=0;i<dim;i++)
	{
		temp.qIndex=i;
		for(int j=0;j<dim;j++)
		{
			temp.pIndex=j;
			temp.costValue=costMatrix[i][j];
			sortCostList.push_back(temp);
		}
	}
	//Sort it in increasing order by value
	sort(sortCostList.begin(),sortCostList.end(),compare);
}

inline double greedyAlgorithm(vector<index_Cost>& sortCostList,double**costMatrix,int dim,double*qVector,double*pVector/*,bool isSparse*/)
{
	int dim_Square;

	for(int i=0;i<dim;i++)
	{
		queryTempVector[i]=qVector[i];
		dataTempVector[i]=pVector[i];
	}

	/*if(isSparse==true)//Use Sparse Processing
	{
		int dim1;
		int dim2;
		sparseProcessing(sortCostList,costMatrix,qVector,pVector,dim,dim1,dim2);
		dim_Square=dim1*dim2;
	}*/
	//else //No Sparse Processing
		dim_Square=dim*dim;

	double Cost=0.0;
	double minFlow;

	for(int index=0;index<dim_Square;index++)
	{
		minFlow=min(queryTempVector[sortCostList[index].qIndex],dataTempVector[sortCostList[index].pIndex]);
		Cost=Cost+sortCostList[index].costValue*minFlow;
		queryTempVector[sortCostList[index].qIndex]=queryTempVector[sortCostList[index].qIndex]-minFlow;
		dataTempVector[sortCostList[index].pIndex]=dataTempVector[sortCostList[index].pIndex]-minFlow;
	}
	return Cost;
}

#endif