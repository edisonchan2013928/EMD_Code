#ifndef UB_H_H
#define UB_H_H

#include "fixed_Cost_Matrix.h"

double*qTempVector;
double*pTempVector;

void initHilbert(char*hilbertDimVector_FileName,fstream& hilbert_DimVector_File,int dim,int*& hilbert_DimVector)
{
	hilbert_DimVector_File.open(hilbertDimVector_FileName);
	if(hilbert_DimVector_File.is_open()==false)
	{
		cout<<"Cannot open hilbert_DimVector_File!"<<endl;
	}

	hilbert_DimVector=new int[dim];
	for(int d=0;d<dim;d++)
		hilbert_DimVector_File>>hilbert_DimVector[d];

	qTempVector=new double[dim];
	pTempVector=new double[dim];
}

double hilbertUB(double*q,double*p,double**costMatrix,int*hilbert_DimVector,int dim)
{
	int leftIndex=0;
	int rightIndex=0;
	int IndexSum=0;
	bool nextLeave=false;

	double UB_Value=0;

	int qMapIndex;
	int pMapIndex;

	//assignment from q and p to qTempVector and pTempVector
	for(int d=0;d<dim;d++)
	{
		qTempVector[d]=q[d];
		pTempVector[d]=p[d];
	}

	while(nextLeave==false)
	{
		if(leftIndex==dim || rightIndex==dim)
			break;

		if(leftIndex==dim-1 && rightIndex==dim-1)
			nextLeave=true;

		qMapIndex=hilbert_DimVector[leftIndex];
		pMapIndex=hilbert_DimVector[rightIndex];

		if(qTempVector[qMapIndex]<pTempVector[pMapIndex])
		{
			UB_Value=UB_Value+costMatrix[qMapIndex][pMapIndex]*qTempVector[qMapIndex];
			pTempVector[pMapIndex]-=qTempVector[qMapIndex];
			qTempVector[qMapIndex]=0;

			leftIndex++;
		}
		if(pTempVector[pMapIndex]<qTempVector[qMapIndex])
		{
			UB_Value=UB_Value+costMatrix[pMapIndex][qMapIndex]*pTempVector[pMapIndex];
			qTempVector[qMapIndex]-=pTempVector[pMapIndex];
			pTempVector[pMapIndex]=0;

			rightIndex++;
		}

		if(qTempVector[qMapIndex]==pTempVector[pMapIndex])
		{
			if(leftIndex==rightIndex)
			{
				leftIndex++;
				rightIndex++;
			}
			else
			{
				if(leftIndex<rightIndex)
					leftIndex++;
				else
					rightIndex++;
			}
		}

	}
	return UB_Value;
}

#endif