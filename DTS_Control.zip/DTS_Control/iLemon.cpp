/*
 * Lemon.cpp
 *
 *  Created on: Apr 8, 2013
 *      Author: yu
 */

#include "iLemon.h"

static const int INF = 500000;

iLemon::iLemon() : cost(graph), capacity(graph), supply(graph), lower(0) {
	// TODO Auto-generated constructor stub
}

iLemon::~iLemon() {
	// TODO Auto-generated destructor stub
}

void iLemon::init(int bin_num, int W, int **costMat)
{
	noA = noB = bin_num;
	TotalCap = W;
	costs = costMat;

	std::vector<lemon::SmartDigraph::Node> nodes(noA+noB+2); // two parts plus the src and sink
	for (int i = 0; i < noA+noB; i++) {
		nodes[i] = graph.addNode();
		supply.set(nodes[i], 0);
	}
	// source point.

	nodes[noA+noB] = graph.addNode();
	supply.set(nodes[noA+noB], TotalCap);
	// sink point.
	nodes[noA+noB+1] = graph.addNode();
	supply.set(nodes[noA+noB+1], -TotalCap);

	lemon::SmartDigraph::Arc arc;

	for (int i = 0; i < noA; i++) {
		arc = graph.addArc(nodes[noA+noB], nodes[i]);
		//capacity.set(arc, int(w1[i]));
		cost.set(arc, 0);
	}

	for (int i = 0; i < noB; i++) {
		arc = graph.addArc(nodes[noA+i], nodes[noA+noB+1]);
		//capacity.set(arc, int(w2[i]));
		cost.set(arc, 0);
	}

	for (int i = 0; i < noA; i++) {
		for (int j = 0; j < noB; j++) {
			arc = graph.addArc(nodes[i], nodes[noA+j]);
			capacity.set(arc, TotalCap);
			cost.set(arc, costs[i][j]);
		}
	}
}

double iLemon::getAssignment(double *w1, double *w2, int MODE = 1)
{
	for (int i = 0; i < noA; i++) {
		capacity.set(graph.arcFromId(i), int(w1[i]));
	}

	for (int i = 0; i < noB; i++) {
		capacity.set(graph.arcFromId(i+noA), int(w2[i]));
	}

	if (MODE == 1)
	{
		lemon::CostScaling<lemon::SmartDigraph, int, int> mcf(graph);
		mcf.upperMap(capacity).costMap(cost).lowerMap(lower).supplyMap(supply);

		//mcf.run(lemon::CostScaling<lemon::SmartDigraph, int, double>::AUGMENT);
		mcf.run();
		double res = mcf.totalCost();
		return res;
	}
	else if (MODE == 2)
	{
		lemon::CapacityScaling<lemon::SmartDigraph, int, int> mcf(graph);
		mcf.upperMap(capacity).costMap(cost).lowerMap(lower).supplyMap(supply);

		//mcf.run(lemon::CapacityScaling<lemon::SmartDigraph, int, double>);
		mcf.run();
		double res = mcf.totalCost();
		return res;
	}
	else if (MODE == 3)
	{
		lemon::NetworkSimplex<lemon::SmartDigraph, int, int> mcf(graph);
		mcf.upperMap(capacity).costMap(cost).lowerMap(lower).supplyMap(supply);

		//mcf.run(lemon::CapacityScaling<lemon::SmartDigraph, int, double>);
		mcf.run();
		double res = mcf.totalCost();
		return res;
	}
}

