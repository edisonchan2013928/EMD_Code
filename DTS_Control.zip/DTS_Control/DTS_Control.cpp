#include "DTS_Control.h"

//declare the model of EMD
EMD model;

int main(int argc,char**argv)
{
	/*int dim=64;
	char*dataSetFileName=(char*)"../../../Image_Dataset/256_ObjectCategories_64RGB_FV/256_ObjectCategories_64RGB_FVMatrix.txt";
	char*costMatrixFileName=(char*)"../../../Image_Dataset/costMatrix_64RGB.txt";
	char*pairFileName=(char*)"../../../Image_Dataset/Pair_File/256_OC_1000Pairs.txt";
	char*groundFileName=(char*)"../../../Image_Dataset/ground_vector_64RGB.txt";
	char*resultFileName=(char*)"256_OC_RGB_Test_alpha.txt";
	double epsilon=0.01;*/
	int dim=(int)atoi(argv[1]);
	char*dataSetFileName=argv[2];
	//char*costMatrixFileName=argv[3];
	char*pairFileName=argv[3];
	char*groundFileName=argv[4];
	char*hilbertDimVector_FileName=argv[5];
	char*resultFileName=argv[6];
	double epsilon=atof(argv[7]);
	int exact_Sel=atoi(argv[8]);

	fstream dataSetFile;
	//fstream costMatrixFile;
	fstream pairFile;
	fstream resultFile;
	fstream groundFile;
	fstream hilbertDimVector_File;

	double**costMatrix;
	double**dataSetVector;
	double**groundMatrix;
	double*feat; //Used in SIA Code to represent the ground feature
	int*hilbert_DimVector;
	Pair*Pair_Array;

	loadData(dataSetFile,dataSetFile,pairFile,/*costMatrixFile,*/
		resultFile,dataSetFileName,dataSetFileName,/*costMatrixFileName,*/
		pairFileName,resultFileName,dataSetVector,dataSetVector,costMatrix,dim,
		true,Pair_Array);

	//loadGroundFile(groundFile,groundFileName,groundMatrix,dim);
	loadGroundFile(groundFile,groundFileName,groundMatrix,feat,dim);

	initHilbert(hilbertDimVector_FileName,hilbertDimVector_File,dim,hilbert_DimVector);

	//Preprocessing SIA
	//**********************************************************//
	model.set(dim, ground_Dim, feat);
	//scaling(dataSetVector,dim,scal_Factor);
	model.initCCA();
	//**********************************************************//
	
	//Obtain Cost Matrix from SIA
	//***********************************//
	costMatrix=model.cost_matrix;
	//***********************************//

	DTS_Control(Pair_Array,dataSetVector,costMatrix,groundMatrix,hilbert_DimVector,dim,epsilon,model,exact_Sel);

	outputResultFile(resultFile);

	//closeFile(dataSetFile,pairFile,hilbertDimVector_File,resultFile);
	closeFile(dataSetFile,pairFile,resultFile,resultFile);

	//closeFile(dataSetFile,pairFile,costMatrixFile,resultFile);
	//close_SingleFile(hilbertDimVector_File);

}
