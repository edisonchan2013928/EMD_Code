#ifndef IM_LB_H
#define IM_LB_H

#include "fixed_Cost_Matrix.h"

double*LVectorTemp;
double*RVectorTemp;

struct component
{
	int rIndex;
	double cost;
};

bool compFunctionCostAscend(component c1,component c2)
{
	return (c1.cost<c2.cost);
}

void init_component(vector< vector<component> >& SortCostVector,double**costMatrix,int dim)
{
	//init LVectorTemp and RVectorTemp
	LVectorTemp=new double[dim];
	RVectorTemp=new double[dim];

	vector<component> tempVectorComponent;
	component tempComponent;

	for(int i=0;i<dim;i++)
	{
		SortCostVector.push_back(tempVectorComponent);
		for(int j=0;j<dim;j++)
		{
			tempComponent.rIndex=j;
			tempComponent.cost=costMatrix[i][j];
			SortCostVector[i].push_back(tempComponent);
		}
	}

	//Do the sorting in increasing order according to the cost value
	for(int i=0;i<dim;i++)
		sort(SortCostVector[i].begin(),SortCostVector[i].end(),compFunctionCostAscend);

}

double IM_LB(double*LVector,double*RVector,vector< vector<component> >& SortCostVector,int dim)
{
	double flow=0.0;
	double IMValue=0.0;

	for(int i=0;i<dim;i++)
	{
		LVectorTemp[i]=LVector[i]-min(LVector[i],RVector[i]);
		RVectorTemp[i]=RVector[i]-min(LVector[i],RVector[i]);
	}

	for(int i=0;i<dim;i++)
	{
		for(int j=0;j<dim;j++)
		{
			flow=min(LVectorTemp[i],RVectorTemp[SortCostVector[i][j].rIndex]);
			IMValue=IMValue+flow*SortCostVector[i][j].cost;
			LVectorTemp[i]=LVectorTemp[i]-flow;
			if(LVectorTemp[i]<0.0)
				continue;
		}
	}

	return IMValue;
}

#endif