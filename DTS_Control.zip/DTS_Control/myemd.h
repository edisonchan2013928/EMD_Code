// EMD for variant number of features.
//
// Edited by Edison
// Last modified: 30/05/2017.
#ifndef	__MYEMD__
#define __MYEMD__

#include "alglib/ap.h"
#include "alglib/dataanalysis.h"


#define DEBUG_LEVEL 0

#include "OptAssign.h"
#include "SpatialCCA.h"

#include "iLemon.h"

//#include "utilities.h"
/*
DEBUG_LEVEL:
0 = NO MESSAGES
1 = PRINT THE NUMBER OF ITERATIONS AND THE FINAL RESULT
2 = PRINT THE RESULT AFTER EVERY ITERATION
3 = PRINT ALSO THE FLOW AFTER EVERY ITERATION
4 = PRINT A LOT OF INFORMATION (PROBABLY USEFUL ONLY FOR THE AUTHOR)
*/


/* NEW TYPES DEFINITION */

/* node1_t IS USED FOR SINGLE-LINKED LISTS */
typedef struct node1_t {
	int i;
	double val;
	struct node1_t *Next;
} node1_t;

/* node1_t IS USED FOR DOUBLE-LINKED LISTS */
typedef struct node2_t {
	int i, j;
	double val;
	struct node2_t *NextC;               /* NEXT COLUMN */
	struct node2_t *NextR;               /* NEXT ROW */
} node2_t;

//modified by edison

//typedef struct
//{
//  int n;                /* Number of features in the signature */
//  double *Features;      /* Pointer to the fldouble EMD::emd(signature_t *Signature1, signature_t *Signature2, flow_t *Flow, int *FlowSize)
//attend features vector */
//  double *Weights;       /* Pointer to the weights of the features */
//} signature_t;


//typedef struct
//{
//  int from;             /* Feature number in signature 1 */
//  int to;               /* Feature number in signature 2 */
//  double amount;         /* Amount of flow from "from" to "to" */
//} flow_t;

struct capacities {
	double* w1;
	double* w2;
};

class EMD {
public:
	// Flattened features matrix bin_coord in row order.
	EMD();
	~EMD();

	void set(int bin_num, int feat_num, double* bin_coord);
	void set_bufsize(int sz);

	void set_DimRed(int bin_num, int feat_dim, double ** costs_red);

	int get_bin_num() { return bin_num; }
	int get_feat_dim() { return feat_dim; }
	
	// conduct PCA on the bins.
	void pca();
	// get the k-th eigen vector, stored in out_array of size dim;
	void get_eigvec(const int kth, double* out_array);
	// get the k-th projection values of each point, stored in out_array of size num;
	void get_scores(const int kth, double* out_array);
	// return the EMD distance.
	
	//Comment by Edison
	//double dist(double* w1, double* w2);
	
	// return the EMD distance by the min-cost flow algorithm.
	double getDist(double* w1, double* w2, double cur_bound);

	//Comment by Edison (Changed back by Edison on 30/5/2017)
	//*******************************************************//
	double getCapScalingDist(double* w1, double* w2);

	double getCostScalingDist(double* w1, double* w2);

	double getNetworkSimplexDist(double* w1, double* w2);
	//*******************************************************//

	double getIthDist(int ith, double cur_bound);
	void prepareEMD(int ith, double* w1, double* w2);
	// init for flow algorithms.
	void initCCA();

	//Changed back by Edison
	void initLemon(int W);

	double getBoundIM(const double * w1, const double * w2);

	// For EMD.
	//double emd(signature_t *Signature1, signature_t *Signature2, flow_t *Flow, int *FlowSize);

	vector<CSpatialCCA> tests;
	vector<int> pids;

	double** cost_matrix;
	int** cost_matrix_INT;

		// Yu
	CSpatialCCA test;

	iLemon lemon;

private:
	// For PCA
	// this guy gets passed in and is filled in with an integer status code
	alglib::ae_int_t info;
	// points matrix, each row as a point
	alglib::real_2d_array bins;
	// scalar values that describe variances along each eigenvector
	alglib::real_1d_array eig_values;
	// unit eigenvectors which are the orthogonal basis that we want
	alglib::real_2d_array eig_vectors;
	// projections of each point with each column as one projected dimension score
	alglib::real_2d_array bin_scores;

	//Comment by Edison
	/*double init(signature_t *Signature1, signature_t *Signature2);
	void findBasicVariables(node1_t *U, node1_t *V);
	int isOptimal(node1_t *U, node1_t *V);
	int findLoop(node2_t **Loop);
	void newSol();
	void russel(double *S, double *D);
	void addBasicVariable(int minI, int minJ, double *S, double *D, 
			     node1_t *PrevUMinI, node1_t *PrevVMinJ,
			     node1_t *UHead);
#if DEBUG_LEVEL > 0
	void printSolution();
#endif*/

	// number of pionts
	int bin_num;
	// number of dimensions
	int feat_dim;

	double* bin_coord;


	double maxc;
	int** sorted_index;



};

#endif
