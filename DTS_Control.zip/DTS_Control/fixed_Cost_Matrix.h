#ifndef FIXED_COST_MATRIX_H
#define FIXED_COST_MATRIX_H

#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <fstream>
#include <time.h>
#include <stdlib.h>

using namespace std;

//It does not change once fixed
//**********************************//
int queryNum;
int dataNum;
int pairNum; //Used in all files
//**********************************//

//It stores the result of all algorithms
//*****************************************//
vector<double> result_pairVector;
//*****************************************//

//Define infinity
int intINF=2147483647;
double inf=2000000000000;
double scal_Factor=1000;

struct Pair
{
	int L_Index;
	int R_Index;
};

void Pair_Array_Init(fstream& pairFile,Pair* &Pair_Array)
{
	Pair_Array=new Pair[pairNum];
	int tempIndex;

	for(int i=0;i<pairNum;i++)
	{
		pairFile>>tempIndex;
		Pair_Array[i].L_Index=tempIndex;
		pairFile>>tempIndex;
		Pair_Array[i].R_Index=tempIndex;
	}
}

void loadObject(fstream& objectSetFile,double**& objectSetVector,int objectNum,int dim)
{
	objectSetVector=new double*[objectNum];
	for(int i=0;i<objectNum;i++)
	{
		objectSetVector[i]=new double[dim];
	}

	for(int i=0;i<objectNum;i++)
	{
		for(int d=0;d<dim;d++)
		{
			objectSetFile>>objectSetVector[i][d];
		}
	}
}

bool loadData(fstream& querySetFile, fstream& dataSetFile,fstream& pairFile,/* fstream& costMatrixFile,*/ fstream& resultFile,
			  char*queryFileName, char*dataFileName, /*char*costMatrixFileName,*/ char*pairFileName ,char*resultFileName,
			  double** &querySetVector,double** &dataSetVector,double** &costMatrix,int dim,
			  bool isPair,Pair* &Pair_Array)
{
	if(isPair==true)//Pair EMD
	{
		pairFile.open(pairFileName);
		if(pairFile.is_open()==false)
		{
			cout<<"Cannot Open Pair File! "<<endl;
			return false;
		}
		pairFile>>pairNum;
		Pair_Array_Init(pairFile,Pair_Array);
	}
		
	dataSetFile.open(dataFileName);
	//costMatrixFile.open(costMatrixFileName);
	resultFile.open(resultFileName,ios::in | ios::out | ios::trunc);

	if(dataSetFile.is_open()!=true /*|| costMatrixFile.is_open()!=true*/ || resultFile.is_open()!=true)
	{
		cout<<"Cannot Open File!"<<endl;
		return false;
	}

	//load data to dataSetVector and costMatrix
	//****************************************//
	dataSetFile>>dataNum;
	loadObject(dataSetFile,dataSetVector,dataNum,dim);
	//loadObject(costMatrixFile,costMatrix,dim,dim);
	//****************************************//

	return true;
}

void scaling(double**dataSetVector,int dim,double scal_Factor)
{
	for(int i=0;i<dataNum;i++)
	{
		for(int d=0;d<dim;d++)
		{
			dataSetVector[i][d]=dataSetVector[i][d]*scal_Factor;
		}
	}
}

void closeFile(fstream& aFile,fstream& bFile,fstream& cFile,fstream& dFile)
{
	aFile.close();
	bFile.close();
	cFile.close();
	dFile.close();
}

void close_SingleFile(fstream& file)
{
	file.close();
}

void outputResultFile(fstream& resultFile)
{
	for(int p=0;p<pairNum;p++)
		resultFile<<result_pairVector[p]<<endl;
}

#endif
