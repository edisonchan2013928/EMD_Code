#ifndef SKEW_BOUND_H
#define SKEW_BOUND_H

#include "myemd.h"
#include "fixed_Cost_Matrix.h"

void initMaterialVector(vector<double>& UB_deltaVector,vector< vector<double> >& SkewMater_Vector,int dim)
{
	//Used in SVSF_STD_Advance 
	vector<double> tempSkewMater_Vector;
	double temp=0;

	for(int d=0;d<dim;d++)
	{
		SkewMater_Vector.push_back(tempSkewMater_Vector);
		for(int dd=0;dd<dim;dd++)
			SkewMater_Vector[d].push_back(temp);

		UB_deltaVector.push_back(temp);
	}
	
}

void init_SkewedVector(double*& q_dash,double*& p_dash,int dim)
{
	q_dash=new double[dim];
	p_dash=new double[dim];
}

//Do it one time when q comes
int SVSF_Mater(double*q,double**C,int dim,double*q_dash,
					  vector<double>& UB_deltaVector,vector< vector<double> >& SkewMater_Vector)
{
	int NZ_q=0;
	double min;
	double c_min;
	double UB_delta=0;
	int alpha,beta;

	for(int d=0;d<dim;d++)
	{
		q_dash[d]=q[d];
		SkewMater_Vector[0][d]=q_dash[d];
		if(q[d]>0)
			NZ_q++; //get the NZ(q)
	}
	UB_deltaVector[0]=0;

	//find min q_\alpha
	for(int iter=1;iter<=NZ_q-1;iter++)
	{
		min=inf;
		//find minimum in q_dash
		for(int i=0;i<dim;i++)
		{
			if(q_dash[i]<min && q_dash[i]>0)
			{
				alpha=i;
				min=q_dash[i];
			}
		}

		//find min c[alpha,beta]
		c_min=inf;
		for(int j=0;j<dim;j++)
		{
			if(q_dash[j]>0 && j!=alpha && C[alpha][j]<c_min)
			{
				beta=j;
				c_min=C[alpha][j];
			}
		}

		UB_delta=UB_delta+C[alpha][beta]*q_dash[alpha];

		q_dash[beta]=q_dash[beta]+q_dash[alpha];
		q_dash[alpha]=0;

		//After this step we materialize this vector and UB_delta
		for(int d=0;d<dim;d++)
		{
			SkewMater_Vector[iter][d]=q_dash[d];
		}
		UB_deltaVector[iter]=UB_delta;
	}
	return NZ_q;
}

/*void skew_LB_UB(double*q_dash,double*p_dash,double ub_delta_q,double ub_delta_p,double**costMatrix,int dim,vector<double>& q_bar,vector<double>& p_bar,double& LB_skew,double& UB_skew)
{
	double EMD_value;
	//double LB_value;

	//IgnoreZero(q_dash,p_dash,q_bar,p_bar,costMatrix,dim);
	//EMD_value=emdComputation(q_bar,p_bar);

	LB_skew=EMD_value-ub_delta_q-ub_delta_p;
	UB_skew=EMD_value+ub_delta_q+ub_delta_p;

	if(LB_skew<0)
		LB_skew=0;
}*/

#endif
