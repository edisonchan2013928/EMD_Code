#Compilation
g++ -c emd.cpp -w

g++ DTS_Control.cpp -O3 -w -o DTS_Control myemd.o iLemon.o nheap.o OptAssign.o OptUpdate.o SpatialCCA.o ./rtree/rtree.o ./rtree/blk_file.o ./rtree/functions.o ./rtree/hilbert.o ./rtree/linlist.o ./alglib/ap.o ./alglib/dataanalysis.o ./alglib/alglibinternal.o ./alglib/alglibmisc.o ./alglib/linalg.o ./alglib/optimization.o ./alglib/solvers.o ./alglib/specialfunctions.o ./alglib/statistics.o emd.o

DTS_Control()
{
	dim=$1
	dataSetFileName=$2
	pairFilePrefix=$3
	groundFileName=$4
	hilbertDimVector_FileName=$5
	resultFilePrefix=$6
	exact_Sel=$7

	fileSuffix=".txt"

	resultFileSuffix="_DTS"$fileSuffix
	timeLogFile=$resultFilePrefix"DTS_timelog.txt"

	pairFileName=$pairFilePrefix"1000Pairs"$fileSuffix
	
	epsilon_Array[0]="0.01"
	epsilon_Array[1]="0.05"
	epsilon_Array[2]="0.1"
	epsilon_Array[3]="0.15"
	epsilon_Array[4]="0.2"
	epsilon_Array[5]="0.25"
	epsilon_Array[6]="0.3"
	
	for (( e = 0; e < 7; ++e ));
	do

		#s=$(expr $e - 2)

		#echo $s
		if [ $e != 0 ]
		then
	
	   		f_val=$( expr 5 '*' $e )
			epsilon=${epsilon_Array[$e]}
		else
			f_val=1
			epsilon=${epsilon_Array[$e]}
		fi

		#echo $exact_Sel

		#f_val=$( expr 5 '*' $e )
		
		#epsilon=${epsilon_Array[$e]}
		epsilon=${epsilon_Array[$e]}

		resultFileName=$resultFilePrefix$dim"_"$f_val$resultFileSuffix

		./DTS_Control $dim $dataSetFileName $pairFileName $groundFileName $hilbertDimVector_FileName $resultFileName $epsilon 2

		Err=$?; 
		if [ $Err -ne 0 ];
		then
			echo ./DTS_Control $dim $dataSetFileName $pairFileName $groundFileName $hilbertDimVector_FileName $resultFileName $epsilon $exact_Sel
		fi

	done	
}

#RGB Extraction
dim=64
num_pair=4
groundFileName="../Image_Dataset/ground_vector_64RGB.txt"
hilbertDimVector_FileName="../Image_Dataset/RGB_hilbertDimVector.txt"

#dataset: 256_OC
dataSetFileName="../Image_Dataset/256_ObjectCategories_64RGB_FV/256_ObjectCategories_64RGB_FVMatrix.txt"
pairFilePrefix="../Image_Dataset/Pair_File/256_OC_"
resultFilePrefix="./Result/256_OC_RGB_"

DTS_Control $dim $dataSetFileName $pairFilePrefix $groundFileName $hilbertDimVector_FileName $resultFilePrefix 2
